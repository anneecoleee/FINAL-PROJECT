package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class EmEmailUp extends JFrame {

	Connection conn = null;
	PreparedStatement stat =null;
	ResultSet rs = null;
	
	private JPanel contentPane;
	private JTextField txtE;
	private JTextField txtAD;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					EmEmailUp frame = new EmEmailUp();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public EmEmailUp() {
		setBounds(100, 100, 356, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Enter Employee ID\r\n\r\n");
		label.setFont(new Font("Tahoma", Font.BOLD, 12));
		label.setBounds(79, 54, 134, 17);
		contentPane.add(label);
		
		txtE = new JTextField();
		txtE.setColumns(10);
		txtE.setBounds(79, 82, 147, 20);
		contentPane.add(txtE);
		
		JLabel label_1 = new JLabel("New Employee Address");
		label_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		label_1.setBounds(79, 125, 197, 17);
		contentPane.add(label_1);
		
		txtAD = new JTextField();
		txtAD.setColumns(10);
		txtAD.setBounds(79, 146, 147, 20);
		contentPane.add(txtAD);
		
		JButton button = new JButton("UPDATE\r\n");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {
					String sql = "Update employee SET Employee_Email=? WHERE Employee_ID=?";
						
					conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
					stat = conn.prepareStatement(sql);
			
					stat.setString(2,txtE.getText());
					stat.setString(1,txtAD.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
					
					
				}
			dispose();
				
			}
			
		});
		button.setBounds(100, 180, 89, 23);
		contentPane.add(button);
	}

}
