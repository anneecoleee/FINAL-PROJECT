package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class EmployeeForm extends JFrame {
	
	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTextField EID;
	private JTextField EN;
	private JTextField EPN;
	private JTextField EA;
	private JTextField EE;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
	//		public void run() {
	//			try {
	//				EmployeeForm frame = new EmployeeForm();
	//				frame.setVisible(true);
	//			} catch (Exception e) {
	//				e.printStackTrace();
	//			}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public EmployeeForm() {
		
		setBounds(100, 100, 383, 397);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(210, 105, 30));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEmployeeId = new JLabel("Employee ID");
		lblEmployeeId.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblEmployeeId.setBounds(31, 63, 113, 20);
		contentPane.add(lblEmployeeId);
		
		JLabel lblEmployeeName = new JLabel("Employee Name");
		lblEmployeeName.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblEmployeeName.setBounds(31, 110, 113, 18);
		contentPane.add(lblEmployeeName);
		
		JLabel lblEmployeePhoneNumber = new JLabel("Employee Phone Number");
		lblEmployeePhoneNumber.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblEmployeePhoneNumber.setBounds(31, 158, 176, 20);
		contentPane.add(lblEmployeePhoneNumber);
		
		JLabel lblEmployeeAddress = new JLabel("Employee Address");
		lblEmployeeAddress.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblEmployeeAddress.setBounds(31, 208, 176, 20);
		contentPane.add(lblEmployeeAddress);
		
		JLabel lblEmployeeEmail = new JLabel("Employee Email");
		lblEmployeeEmail.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblEmployeeEmail.setBounds(31, 251, 176, 18);
		contentPane.add(lblEmployeeEmail);
		
		EID = new JTextField();
		EID.setColumns(10);
		EID.setBounds(226, 63, 113, 20);
		contentPane.add(EID);
		
		EN = new JTextField();
		EN.setColumns(10);
		EN.setBounds(226, 108, 113, 20);
		contentPane.add(EN);
		
		EPN = new JTextField();
		EPN.setColumns(10);
		EPN.setBounds(226, 156, 113, 20);
		contentPane.add(EPN);
		
		EA = new JTextField();
		EA.setColumns(10);
		EA.setBounds(226, 206, 113, 20);
		contentPane.add(EA);
		
		EE = new JTextField();
		EE.setColumns(10);
		EE.setBounds(226, 249, 113, 20);
		contentPane.add(EE);
		
		JButton btnAddTheEmployee = new JButton("ADD THE EMPLOYEE");
		btnAddTheEmployee.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
try {
					
					String sql = "Insert into employee" + "(Employee_ID,Employee_Name,Employee_Phone_Number,Employee_Address,Employee_Email)" 
									+ "values (?,?,?,?,?)";
					conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
					stat = conn.prepareStatement(sql);
					stat.setString(1,EID.getText());
					stat.setString(2,EN.getText()); 
					stat.setString(3,EPN.getText());
					stat.setString(4,EA.getText());
					stat.setString(5,EE.getText());
					
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "A New Employee Added");	
					
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
							
				}
		EmpSTocks frame = new EmpSTocks();
		frame.EmployeeTable();
			}
		});
		btnAddTheEmployee.setBounds(104, 295, 149, 35);
		contentPane.add(btnAddTheEmployee);
		
		JLabel lbladdAnEmployee = new JLabel("ADD AN EMPLOYEE");
		lbladdAnEmployee.setFont(new Font("SimSun", Font.BOLD, 18));
		lbladdAnEmployee.setBounds(104, 23, 160, 30);
		contentPane.add(lbladdAnEmployee);
	}
}
