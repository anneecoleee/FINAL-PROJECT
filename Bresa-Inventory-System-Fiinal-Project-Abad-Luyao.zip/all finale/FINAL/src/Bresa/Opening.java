package Bresa;

import java.awt.event.ActionEvent;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.SystemColor;
import javax.swing.UIManager;



public class Opening extends JFrame {
	
	
	
	Connection conn = null;
	/**
	 * 
	 */
	PreparedStatement stat = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTable table;
	private JTable SupTab;
	private JTextField txtsearch;
	private JTextField txtSID;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Opening frame = new Opening();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
public void ProdTables() {
		
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
			String sql = "Select *from products";
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
	
		}catch(Exception ex) {
		 	
			JOptionPane.showMessageDialog(null, ex);		
		}

		
	}
public void SuppTables() {
	
	try {
		
		conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
		String sql = "Select *from supplier";
		stat = conn.prepareStatement(sql);
		rs = stat.executeQuery();
		SupTab.setModel(DbUtils.resultSetToTableModel(rs));

		
				
	}catch(Exception ex) {
	 	
		JOptionPane.showMessageDialog(null, ex);		
	}
	
	
}

public void SearchTables() {
	
	try {
		
		
		conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
		String sql = "Select *from products WHERE Product_ID=?";
		stat = conn.prepareStatement(sql);
		stat.setString(1,txtsearch.getText());	
		rs = stat.executeQuery();
		table.setModel(DbUtils.resultSetToTableModel(rs));

		
				
	}catch(Exception ex) {
	 	
		JOptionPane.showMessageDialog(null, ex);		
	}
	
	
}
public void SearchTables2() {
	
	try {
		
		
		conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
		String sql = "Select *from supplier WHERE Supplier_ID=?";
		stat = conn.prepareStatement(sql);
		stat.setString(1,txtSID.getText());	
		rs = stat.executeQuery();
		SupTab.setModel(DbUtils.resultSetToTableModel(rs));

		
				
	}catch(Exception ex) {
	 	
		JOptionPane.showMessageDialog(null, ex);		
	}
	
	
}


	/**
	 * Create the frame.
	 */
	public Opening() {
		setBackground(Color.BLACK);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1183, 555);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(435, 11, 384, 41);
		panel.setBackground(new Color(205, 133, 63));
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(186, 53, 291, 23);
		panel.add(panel_3);
		panel_3.setBackground(Color.LIGHT_GRAY);
		panel_3.setLayout(null);
		
		JLabel lblWelcomeToBresa = new JLabel("BRESA DRUG STORE INVENTORY SYSTEM");
		lblWelcomeToBresa.setBounds(10, 11, 363, 20);
		panel.add(lblWelcomeToBresa);
		lblWelcomeToBresa.setFont(new Font("SimSun", Font.BOLD, 19));
		
		JButton btnNewButton = new JButton("ADD A PRODUCT");
		btnNewButton.setBackground(UIManager.getColor("Button.background"));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(29, 99, 166, 25);
	btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
//				
				
				OPENNINNNINGGG frame = new OPENNINNNINGGG();
				frame.setVisible(true);
				
				
	//			try {
	//				String sql = "Insert into products" + "(Product_ID,Product_Name,Category,Selling_Price,Quantity,Generic_Name,Manufactured_Date,Expiration_Date,Manufacturer)" 
	//								+ "values (?,?,?,?,?,?,?,?,?)";
	//				conn = DriverManager.getConnection("jdbc:mysql://localhost/products","root","boboka");
	//				stat = conn.prepareStatement(sql);
		///			
		//			stat.setString(1,txtID.getText());
		//			stat.setString(2,txtName.getText()); 
		///			stat.setString(3,txtCat.getText());
		//			stat.setString(4,txtSP.getText());
			//		stat.setString(5,txtQ.getText());
		//			stat.setString(6,txtGName.getText());
		//			stat.setString(7,txtMD.getText());
		//			stat.setString(8,txtMan.getText());
		//			stat.setString(9,txtED.getText());
		//			stat.executeUpdate();
		//			JOptionPane.showMessageDialog(null, "Product Added");	
		//			
		//		}catch(SQLException	| HeadlessException ex) {
		//			
		//			JOptionPane.showMessageDialog(null, ex);

					
				//}
//				ProdTables();
//			}
			}});
		contentPane.add(btnNewButton);
		
		JButton btnUpdateAProduct = new JButton("UPDATE A PRODUCT");
		btnUpdateAProduct.setBackground(UIManager.getColor("Button.background"));
		btnUpdateAProduct.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnUpdateAProduct.setBounds(29, 167, 166, 23);
		btnUpdateAProduct.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				UPDATEEE frame = new UPDATEEE();
				frame.setVisible(true);
				
				
				
		//		try {
		//			String sql = "Update products SET Product_Name=?,Category=?,Selling_Price=?,Quantity=?,Generic_Name=?,Manufactured_Date=?,Expiration_Date=?,Manufacturer=? WHERE Product_ID=?";
		//			conn = DriverManager.getConnection("jdbc:mysql://localhost/products","root","boboka");
		//			stat = conn.prepareStatement(sql);
		//			
		///			stat.setString(9,txtID.getText());
		//			stat.setString(1,txtName.getText());
		//			stat.setString(2,txtCat.getText());
		//			stat.setString(3,txtSP.getText());
		///			stat.setString(4,txtQ.getText());
		//			stat.setString(5,txtGName.getText());
		//			stat.setString(6,txtMD.getText());
		//			stat.setString(7,txtMan.getText());
		///			stat.setString(8,txtED.getText());
		//			stat.executeUpdate();
		//			JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
		//			
		//		}catch(SQLException	| HeadlessException ex) {
		//			
		//			JOptionPane.showMessageDialog(null, ex);
		//			
		//			
		//		}	
		//		ProdTables();
			}
		});
		contentPane.add(btnUpdateAProduct);
		
		JButton btnRemoveAProduct = new JButton("REMOVE A PRODUCT\r\n");
		btnRemoveAProduct.setBackground(UIManager.getColor("Button.background"));
		btnRemoveAProduct.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnRemoveAProduct.setBounds(30, 135, 165, 23);
		btnRemoveAProduct.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				REMOOOVEEE frame = new REMOOOVEEE();
				frame.setVisible(true);
				
				
	//			try {
	//				String sql = "Delete from products where Product_ID =?";
	//				conn = DriverManager.getConnection("jdbc:mysql://localhost/products","root","boboka");jn
	//				stat = conn.prepareStatement(sql);
	//				stat.setString(1,txtID2.getText());	
	//				stat.executeUpdate();
	//				
	//				
	//				JOptionPane.showMessageDialog(null, "Product Deleted");
	//				
	//				
	//				
	//			}
	//			catch(SQLException	| HeadlessException ex) {
	//				
	//				JOptionPane.showMessageDialog(null, ex);
	///				
	///			}
	//			ProdTables();
			}
		});
		contentPane.add(btnRemoveAProduct);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(207, 99, 940, 130);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setBackground(new Color(255, 250, 250));
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Product_ID", "Product_Name", "Category", "Selling_Price", "Quantity", "Generic_Name", "Manufactured_Date", "Expiration_Date", "Manufacturer", "Supplier_ID"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class, Double.class, Integer.class, String.class, String.class, String.class, String.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(198, 345, 949, 158);
		contentPane.add(scrollPane_1);
		
		SupTab = new JTable();
		scrollPane_1.setViewportView(SupTab);
		SupTab.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Supplier_ID", "Supplier_Name", "Supplier_Email", "Supplier_Phone_Number", "Batch_Number", "Supplier_Address"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class, Integer.class, Integer.class, String.class
			};
			@Override
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JButton btnAddASupplier = new JButton("ADD SUPPLIER\r\n");
		btnAddASupplier.setBackground(UIManager.getColor("Button.background"));
		btnAddASupplier.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnAddASupplier.setBounds(29, 347, 158, 23);
		btnAddASupplier.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				
				AddSupplier frame = new AddSupplier();
				frame.setVisible(true);
				
	//					try {
	//				String sql = "Insert into supplier" + "(Supplier_ID,Supplier_Name,Supplier_Email,Supplier_Phone_Number,Batch_Number,Supplier_Address)" 
	//								+ "values (?,?,?,?,?,?)";
	//				conn = DriverManager.getConnection("jdbc:mysql://localhost/products","root","boboka");
	//				stat = conn.prepareStatement(sql);
	//				
	//				stat.setString(1,SupID.getText());
	//				stat.setString(2,SupN.getText()); 
	//				stat.setString(3,SupEm.getText());
		//			stat.setString(4,SupNum.getText());
		///			stat.setString(5,txtBN.getText());
		//			stat.setString(6,SupAd.getText());
		//			stat.executeUpdate();
		//			JOptionPane.showMessageDialog(null, "A New Supplier Added");	
			//		
		//		}catch(SQLException	| HeadlessException ex) {
		//			
		//			JOptionPane.showMessageDialog(null, ex);
		//		
		//		}
		//		 SuppTables();
				
			}
		});
		contentPane.add(btnAddASupplier);
		
		JButton btnUpdateASupplier = new JButton("UPDATE SUPPLIER\r\n");
		btnUpdateASupplier.setBackground(UIManager.getColor("Button.background"));
		btnUpdateASupplier.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnUpdateASupplier.setBounds(29, 415, 158, 23);
		btnUpdateASupplier.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				SupplierUpdate frame = new SupplierUpdate();
				frame.setVisible(true);
			
	//			try {
	//				String sql = "Update supplier SET Supplier_ID=?,Supplier_Name=?,Supplier_Email=?,Supplier_Phone_Number=?,Batch_Number=?,Supplier_Address=? WHERE Supplier_ID=?";
	//				conn = DriverManager.getConnection("jdbc:mysql://localhost/products","root","boboka");
	//				stat = conn.prepareStatement(sql);
	//				
	//				
	//				stat.setString(5,SupN.getText());
	//				stat.setString(1,SupEm.getText());
	//				stat.setString(2,SupNum.getText());
	//				stat.setString(3,txtBN.getText());
	//				stat.setString(4,SupAd.getText());
	//				
	//				stat.executeUpdate();
	//				JOptionPane.showMessageDialog(null, "Supplier Information is Updated Successfully :) ");		
	//				
	//			}catch(SQLException	| HeadlessException ex) {
	//				
	//				JOptionPane.showMessageDialog(null, ex);
	//				
	//			
	//			
	//		}
	//			SuppTables();
				}}
	);
		contentPane.add(btnUpdateASupplier);
		
		JButton btnRemoveASupplier = new JButton("REMOVE SUPPLIER\r\n");
		btnRemoveASupplier.setBackground(UIManager.getColor("Button.background"));
		btnRemoveASupplier.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnRemoveASupplier.setBounds(26, 381, 161, 23);
		btnRemoveASupplier.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				RemoveSupplier frame = new RemoveSupplier();
				frame.setVisible(true);
				
	//			try {
	///				String sql = "Delete from supplier where Supplier_ID =?";
	//				conn = DriverManager.getConnection("jdbc:mysql://localhost/products","root","boboka");
	//				stat = conn.prepareStatement(sql);
	//				stat.setString(1,Sup3.getText());	
//					stat.executeUpdate();
//					
//					
//					JOptionPane.showMessageDialog(null, "Product Deleted");
//					
//					
//					
//				}
//				catch(SQLException	| HeadlessException ex) {
//					
//					JOptionPane.showMessageDialog(null, ex);
//					
//				}
	//			SuppTables();
			}
		});
		contentPane.add(btnRemoveASupplier);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(207, 294, 291, 35);
		panel_2.setBackground(new Color(205, 133, 63));
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("SUPPLIER'S INFORMATION\r\n");
		lblNewLabel_1.setBounds(10, 11, 279, 23);
		panel_2.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("SimSun", Font.BOLD, 20));
		
		JButton btnNewButton_1 = new JButton("SEARCH PRODUCT\r\n");
		btnNewButton_1.setBackground(UIManager.getColor("Button.background"));
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SearchTables();
			}
		});
		btnNewButton_1.setBounds(984, 63, 163, 25);
		contentPane.add(btnNewButton_1);
		
		txtsearch = new JTextField();
		txtsearch.setText("Enter Product  ID\r\n");
		txtsearch.setBounds(851, 63, 127, 25);
		contentPane.add(txtsearch);
		txtsearch.setColumns(10);
		
		JButton btnRefreshTable = new JButton("REFRESH TABLE");
		btnRefreshTable.setBackground(UIManager.getColor("Button.background"));
		btnRefreshTable.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnRefreshTable.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				ProdTables();
			}
		});
		btnRefreshTable.setBounds(29, 201, 166, 25);
		contentPane.add(btnRefreshTable);
		
		JButton btnRefreshTable_1 = new JButton("REFRESH TABLE");
		btnRefreshTable_1.setBackground(UIManager.getColor("Button.background"));
		btnRefreshTable_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnRefreshTable_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SuppTables();
			}
		});
		btnRefreshTable_1.setBounds(29, 449, 158, 23);
		contentPane.add(btnRefreshTable_1);
		
		txtSID = new JTextField();
		txtSID.setText("Enter Supplier ID");
		txtSID.setColumns(10);
		txtSID.setBounds(851, 294, 127, 24);
		contentPane.add(txtSID);
		
		JButton btnSearchSupplier = new JButton("SEARCH SUPPLIER\r\n");
		btnSearchSupplier.setBackground(UIManager.getColor("Button.background"));
		btnSearchSupplier.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SearchTables2();
			}
		});
		btnSearchSupplier.setBounds(984, 294, 163, 25);
		contentPane.add(btnSearchSupplier);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(205, 133, 63));
		panel_1.setBounds(21, 254, 166, 63);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Other Options\r\n");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(41, 0, 98, 30);
		panel_1.add(lblNewLabel);
		
		JButton btnNewButton_2 = new JButton("Enter Orders");
		btnNewButton_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Orders frame = new Orders();
				frame.setVisible(true);
				
			}
		});
		btnNewButton_2.setBounds(30, 29, 98, 23);
		panel_1.add(btnNewButton_2);
		
		JLabel lblNewLabel_2 = new JLabel("PRODUCT'S INFORMATION\r\n");
		lblNewLabel_2.setBounds(197, 63, 281, 25);
		contentPane.add(lblNewLabel_2);
		lblNewLabel_2.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_2.setFont(new Font("SimSun", Font.BOLD, 20));
		
		JButton btnBackToOptions = new JButton("Back to Options");
		btnBackToOptions.setBackground(UIManager.getColor("Button.background"));
		btnBackToOptions.setBounds(22, 11, 142, 23);
		contentPane.add(btnBackToOptions);
		btnBackToOptions.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				MainFrame frame = new MainFrame();
				frame.setVisible(true);
				dispose();
			}
		});
	}
}
