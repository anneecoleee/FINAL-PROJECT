package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Orders extends JFrame {
	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTextField customer;
	private JTextField cid;
	private JTextField pid;
	private JTextField quantity;
	private JTextField name;
	private JTextField price;
	private JTextField discount;
	private JTextField amount;
	private JTable table;
	private JTextField pname;
	private JTextField custid;
	private JTextField subtotal;
	private JTextField tcash;
	private JTextField change;
	private JTextField total;

	/**
	 * Launch the application.
	 */
	
	public class Function {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		public ResultSet find (String s) {
	
		try {	
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproj","root","boboka");
			ps = conn.prepareStatement("Select * from products where Product_ID = ?");
			ps.setString(1,  s);
			rs = ps.executeQuery();
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex.getMessage());
		}
		return rs;
		} 
	}
	
	public void clearFields () {
		

		cid.setText(null); 
		customer.setText(null);
		pid.setText(null);
		name.setText(null);
		price.setText(null);
		quantity.setText(null);
		discount.setText(null);
		amount.setText(null);
		
	}
	public void clearcustom() {
		
		cid.setText(null);
		customer.setText(null);
		
		
	}
	public void table() {
	
	DefaultTableModel model = (DefaultTableModel)table.getModel();
	model.addRow(new Object[] {name.getText(), price.getText(), quantity.getText(), amount.getText()});
	
	}
	
	public void getSum () {
		double sum = 0;
		for (double i = 0; i < table.getRowCount(); i++)
		{
			sum = sum + Double.parseDouble(table.getValueAt((int) i, 3).toString());
		}
		subtotal.setText(Double.toString(sum));
	}
	
	
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
///			public void run() {
///				try {
///					Orders frame = new Orders();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
	////			}
	//		}
	//	});
//	}

	/**
	 * Create the frame.
	 */
	public Orders() {
		setBounds(100, 100, 1022, 739);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCustomerName = new JLabel("Customer Name");
		lblCustomerName.setBounds(170, 115, 97, 14);
		contentPane.add(lblCustomerName);
		
		JLabel lblCustomerId = new JLabel("Customer ID");
		lblCustomerId.setBounds(23, 115, 76, 14);
		contentPane.add(lblCustomerId);
		
		JLabel lblProductId = new JLabel("Product ID");
		lblProductId.setBounds(23, 171, 76, 14);
		contentPane.add(lblProductId);
		
		JLabel lblProductName = new JLabel("Product Name");
		lblProductName.setBounds(170, 171, 97, 14);
		contentPane.add(lblProductName);
		
		JLabel lblSellingPrice = new JLabel("Selling Price");
		lblSellingPrice.setBounds(23, 227, 76, 14);
		contentPane.add(lblSellingPrice);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setBounds(170, 227, 46, 14);
		contentPane.add(lblQuantity);
		
		customer = new JTextField();
		customer.setBounds(170, 140, 127, 20);
		contentPane.add(customer);
		customer.setColumns(10);
		
		cid = new JTextField();
		cid.setColumns(10);
		cid.setBounds(23, 140, 127, 20);
		contentPane.add(cid);
		
		pid = new JTextField();
		pid.setColumns(10);
		pid.setBounds(23, 196, 127, 20);
		contentPane.add(pid);
		
		quantity = new JTextField();
		quantity.setColumns(10);
		quantity.setBounds(170, 252, 127, 20);
		contentPane.add(quantity);
		
		name = new JTextField();
		name.setColumns(10);
		name.setBounds(170, 199, 127, 20);
		contentPane.add(name);
		
		price = new JTextField();
		price.setColumns(10);
		price.setBounds(23, 252, 127, 20);
		contentPane.add(price);
		
		JLabel lblEnterOrder = new JLabel("ENTER ORDER");
		lblEnterOrder.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblEnterOrder.setBounds(93, 29, 174, 50);
		contentPane.add(lblEnterOrder);
		
		JRadioButton rdbtnPwd = new JRadioButton("PWD");
		rdbtnPwd.setBackground(new Color(205, 133, 63));
		rdbtnPwd.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String txt2 = subtotal.getText();
				double subtotal = Double.parseDouble (txt2);
				double disc = subtotal * 0.20;
				double tot = (subtotal-disc);
				discount.setText("" + disc);
				total.setText("" + tot);
			}
		});
		rdbtnPwd.setBounds(75, 412, 59, 23);
		contentPane.add(rdbtnPwd);
		
		JRadioButton rdbtnSeniorCitizen = new JRadioButton("Senior Citizen");
		rdbtnSeniorCitizen.setBackground(new Color(205, 133, 63));
		rdbtnSeniorCitizen.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String txt2 = subtotal.getText();
				double subtotal = Double.parseDouble (txt2);
				double disc = subtotal * 0.20;
				double tot = (subtotal-disc);
				discount.setText("" + disc);
				total.setText("" + tot);
				
			}
		});
		rdbtnSeniorCitizen.setBounds(132, 412, 97, 23);
		contentPane.add(rdbtnSeniorCitizen);
		
		JLabel lblDiscount = new JLabel("Discount");
		lblDiscount.setBounds(23, 432, 59, 14);
		contentPane.add(lblDiscount);
		
		discount = new JTextField();
		discount.setBounds(23, 457, 127, 20);
		contentPane.add(discount);
		discount.setColumns(10);
		
		amount = new JTextField();
		amount.setColumns(10);
		amount.setBounds(170, 317, 127, 20);
		contentPane.add(amount);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(205, 133, 63));
		panel.setBounds(361, 115, 635, 468);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 39, 589, 405);
		panel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Name", "Price", "Quantity", "Subtotal"
			}
		));
		
		pname = new JTextField();
		pname.setColumns(10);
		pname.setBounds(66, 8, 127, 20);
		panel.add(pname);
		
		custid = new JTextField();
		custid.setColumns(10);
		custid.setBounds(213, 8, 127, 20);
		panel.add(custid);
		
		JLabel lblCustomer = new JLabel("Customer");
		lblCustomer.setBounds(10, 11, 46, 14);
		panel.add(lblCustomer);
		
		JButton btnAddOrder = new JButton("Add Order");
		btnAddOrder.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				table();	
				pname.setText(customer.getText());
				custid.setText(cid.getText());		
				clearFields();
			
					
			}
		});
		btnAddOrder.setBounds(106, 348, 127, 23);
		contentPane.add(btnAddOrder);
		
		JButton Search = new JButton("Search");
		Search.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				Function f = new Function ();
				
				
				
				rs = f.find(pid.getText());
				
				
				
				try {
					if(rs.next()) {
						name.setText(rs.getString("Product_Name"));
						price.setText(rs.getString("Selling_Price"));
						
					}else {
						JOptionPane.showMessageDialog(null, "NO DATA");
					}
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, ex.getMessage());
				}
			
			}
		});
		Search.setBounds(89, 283, 127, 23);
		contentPane.add(Search);
		
		JButton btnTotal = new JButton("Subtotal");
		btnTotal.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getSum();
				
	
			}
		});
		btnTotal.setBounds(23, 382, 127, 23);
		contentPane.add(btnTotal);
		
		subtotal = new JTextField();
		subtotal.setBounds(170, 382, 127, 20);
		contentPane.add(subtotal);
		subtotal.setColumns(10);
		
		JLabel lblTenderedCash = new JLabel("Tendered Cash");
		lblTenderedCash.setBounds(23, 533, 127, 14);
		contentPane.add(lblTenderedCash);
		
		tcash = new JTextField();
		tcash.setBounds(23, 558, 127, 20);
		contentPane.add(tcash);
		tcash.setColumns(10);
		
		change = new JTextField();
		change.setBounds(23, 621, 127, 20);
		contentPane.add(change);
		change.setColumns(10);
		
		JButton btnChange = new JButton("Change");
		btnChange.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			String txt1 = total.getText();
			double total = Double.parseDouble(txt1);
			String txt2 = tcash.getText();
			double tcash = Double.parseDouble(txt2);
			double chan = (tcash-total);
			change.setText("" + chan);
			
			
			}
		});
		btnChange.setBounds(23, 589, 89, 23);
		contentPane.add(btnChange);
		
		JButton btnNewButton = new JButton("Amount");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String txt1 = price.getText();
				double price = Double.parseDouble(txt1);
				String txt2 = quantity.getText();
				double quantity = Double.parseDouble(txt2);
				double tal = price * quantity;
				amount.setText("" + tal);
			}
		});
		btnNewButton.setBounds(23, 317, 122, 23);
		contentPane.add(btnNewButton);
		
		total = new JTextField();
		total.setText("");
		total.setBounds(122, 488, 130, 20);
		contentPane.add(total);
		total.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Total");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				total.setText(subtotal.getText());
			}
		});
		btnNewButton_1.setBounds(23, 488, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblViewSales = new JLabel("VIEW SALES");
		lblViewSales.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblViewSales.setBounds(581, 29, 174, 50);
		contentPane.add(lblViewSales);
	}
}
