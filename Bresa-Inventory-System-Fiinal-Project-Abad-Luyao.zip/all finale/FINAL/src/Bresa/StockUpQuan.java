package Bresa;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class StockUpQuan extends JFrame {
	
	Connection conn= null;
	PreparedStatement stat = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTextField ID;
	private JTextField Quan;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
	///		public void run() {
	//			try {
	//				StockUpQuan frame = new StockUpQuan();
	//				frame.setVisible(true);
	//			} catch (Exception e) {
	//				e.printStackTrace();
	//			}
	//		}
	//	});
//	}

	/**
	 * Create the frame.
	 */
	public StockUpQuan() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 352, 295);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEnterStockId = new JLabel("Enter Stock ID\r\n\r\n");
		lblEnterStockId.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblEnterStockId.setBounds(86, 63, 134, 17);
		contentPane.add(lblEnterStockId);
		
		ID = new JTextField();
		ID.setColumns(10);
		ID.setBounds(86, 87, 147, 20);
		contentPane.add(ID);
		
		JLabel lblNewStockQuantity = new JLabel("New Stock Quantity");
		lblNewStockQuantity.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewStockQuantity.setBounds(86, 134, 134, 17);
		contentPane.add(lblNewStockQuantity);
		
		Quan = new JTextField();
		Quan.setColumns(10);
		Quan.setBounds(86, 162, 147, 20);
		contentPane.add(Quan);
		
		JButton button = new JButton("Update");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String sql = "Update Stocks SET Quantity=? WHERE Stock_ID=?";
						
					conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
					stat = conn.prepareStatement(sql);
			
					stat.setString(2,ID.getText());
					stat.setString(1,Quan.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
					
					
				}
			dispose();
			}
		});
		button.setBounds(116, 193, 89, 23);
		contentPane.add(button);
	}

}
