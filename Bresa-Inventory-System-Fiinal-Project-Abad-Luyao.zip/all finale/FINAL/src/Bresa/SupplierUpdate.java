package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class SupplierUpdate extends JFrame {

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	
	private JPanel contentPane;
	

	/**
	 * Create the frame.
	 */
	public SupplierUpdate() {
		setBounds(100, 100, 832, 391);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblupdateASupplier = new JLabel("\"UPDATE A SUPPLIER\"");
		lblupdateASupplier.setFont(new Font("SimSun", Font.BOLD, 19));
		lblupdateASupplier.setBounds(282, 0, 274, 72);
		contentPane.add(lblupdateASupplier);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(205, 133, 63));
		panel.setBounds(128, 83, 575, 187);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnUpdateSupplierName = new JButton("UPDATE SUPPLIER'S NAME");
		btnUpdateSupplierName.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SupName frame = new SupName();
				frame.setVisible(true);
			}
		});
		btnUpdateSupplierName.setBounds(10, 108, 223, 23);
		panel.add(btnUpdateSupplierName);
		
		JButton btnUpdateSupplierPhone = new JButton("UPDATE SUPPLIER'S PHONE NUMBER");
		btnUpdateSupplierPhone.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SupPnumber frame = new SupPnumber();
				frame.setVisible(true);
			}
		});
		btnUpdateSupplierPhone.setBounds(292, 108, 252, 23);
		panel.add(btnUpdateSupplierPhone);
		
		JButton btnUpdateSupplierEmail = new JButton("UPDATE SUPPLIER'S EMAIL");
		btnUpdateSupplierEmail.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SupEmail frame = new SupEmail();
				frame.setVisible(true);
			}
		});
		btnUpdateSupplierEmail.setBounds(10, 142, 223, 23);
		panel.add(btnUpdateSupplierEmail);
		
		JButton btnUpdateSuppliersAddress = new JButton("UPDATE SUPPLIER'S ADDRESS");
		btnUpdateSuppliersAddress.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SupAddress frame = new SupAddress();
				frame.setVisible(true);
			}
		});
		btnUpdateSuppliersAddress.setBounds(292, 142, 252, 23);
		panel.add(btnUpdateSuppliersAddress);
		
		JLabel label_1 = new JLabel("CHOOSE WHAT TO UPDATE");
		label_1.setFont(new Font("Microsoft YaHei UI Light", Font.BOLD, 16));
		label_1.setBounds(148, 11, 247, 72);
		panel.add(label_1);
	}

}
