package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class UpdateGenericName extends JFrame {

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	
	
	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtGN;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					UpdateGenericName frame = new UpdateGenericName();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public UpdateGenericName() {
	
		setBounds(100, 100, 279, 303);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Enter Product ID\r\n\r\n");
		label.setFont(new Font("Tahoma", Font.BOLD, 12));
		label.setBounds(41, 38, 134, 17);
		contentPane.add(label);
		
		txtID = new JTextField();
		txtID.setColumns(10);
		txtID.setBounds(41, 66, 147, 20);
		contentPane.add(txtID);
		
		JLabel lblNewProductsGeneric = new JLabel("New Product's Generic Name\r\n\r\n");
		lblNewProductsGeneric.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewProductsGeneric.setBounds(41, 112, 193, 17);
		contentPane.add(lblNewProductsGeneric);
		
		txtGN = new JTextField();
		txtGN.setColumns(10);
		txtGN.setBounds(41, 138, 147, 20);
		contentPane.add(txtGN);
		
		JButton button = new JButton("UPDATE\r\n");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String sql = "Update products SET Generic_Name=? WHERE Product_ID=?";
						
				conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
                stat = conn.prepareStatement(sql);
			
					stat.setString(2,txtID.getText());
					stat.setString(1,txtGN.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
					
					
				}
				
				dispose();
			}
		});
		button.setBounds(64, 169, 89, 23);
		contentPane.add(button);
	}

}
