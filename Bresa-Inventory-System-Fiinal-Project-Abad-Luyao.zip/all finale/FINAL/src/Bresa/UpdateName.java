package Bresa;

import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class UpdateName extends JFrame {
	
	Connection conn = null;
	/**
	 * 
	 */
	PreparedStatement stat = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtName;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
	//			try {
	///				UpdateName frame = new UpdateName();
	//				frame.setVisible(true);
	//			} catch (Exception e) {
	//				e.printStackTrace();
	//			}
	//		}
	//	});
//	}

	/**
	 * Create the frame.
	 */
	public UpdateName() {
		setBounds(100, 100, 271, 292);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewProductName = new JLabel("Enter New Product Name");
		lblNewProductName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewProductName.setBounds(56, 109, 157, 16);
		contentPane.add(lblNewProductName);
		
		txtID = new JTextField();
		txtID.setBounds(56, 59, 143, 20);
		contentPane.add(txtID);
		txtID.setColumns(10);
		
		JButton btnNewButton = new JButton("UPDATE");
		btnNewButton.setBounds(81, 166, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String sql = "Update products SET Product_Name=? WHERE Product_ID=?";
						
				conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
                stat = conn.prepareStatement(sql);
			
					stat.setString(2,txtID.getText());
					stat.setString(1,txtName.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
					
					
				}	
				
				dispose();
				
			}
		});
		contentPane.add(btnNewButton);
		
		txtName = new JTextField();
		txtName.setBounds(56, 135, 143, 20);
		txtName.setColumns(10);
		contentPane.add(txtName);
		
		JLabel lblProdcuctName = new JLabel("Enter Product ID\r\n");
		lblProdcuctName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblProdcuctName.setBounds(56, 25, 124, 23);
		contentPane.add(lblProdcuctName);
	}

}
